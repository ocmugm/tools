<?php
// auto generated, do not modify
$strings += array(
		"Document"
		=> "帮助文档",
		"INI Reference"
		=> "INI 参考",
		"Get Support"
		=> "获取支持",
		"Discusson"
		=> "讨论",
		"Cacher"
		=> "缓存器",
		"Coverager"
		=> "代码覆盖查看器",
		"Diagnosis"
		=> "诊断",
		);

