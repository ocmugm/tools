<?php

// [default config]
// DO NOT rename/delete/modify this file which will be overwritten when upgrade
// See config.example.php instead

// detected by browser
// $config['lang'] = 'en-us';

$config['charset'] = "UTF-8";

// translators only
$config['show_todo_strings'] = false;

// this ob filter function is applied for the list with paths, not the whole page
$config['path_nicer'] = 'ob_filter_path_nicer_default';

