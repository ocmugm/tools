<?php

require_once "../common/common.php";

include get_language_file("./lang");
$module = "cacher";

