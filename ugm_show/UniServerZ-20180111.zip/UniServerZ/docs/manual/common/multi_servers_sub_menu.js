document.write('<span class=\"sub_menu_header\">Multi Servers</span>');

document.write('<div id=\"lcon1\">');
document.write('<ul class=\"lmen1\">');

document.write('<li class=\"p1010\"><a href=\"multi_servers_standalone.html\"  target=\"_top\"        >Standalone servers</a></li>');


document.write('</ul>');
document.write('</div>');
