
document.write('<span class=\"sub_menu_header\">Menu - PHP</span>');

document.write('<div id=\"lcon1\">');
document.write('<ul class=\"lmen1\">');

document.write('<li class=\"p810\"><a href=\"php_pear.html\"  target=\"_top\">PEAR Web-Frontend</a></li>');
document.write('<li class=\"p820\"><a href=\"php_pear_auto_install.html\"  target=\"_top\">PEAR Auto Install go-pear</a></li>');
document.write('<li class=\"p830\"><a href=\"php_pear_manual_install.html\"  target=\"_top\">PEAR Manual Install</a></li>');
document.write('<li class=\"p840\"><a href=\"php_version_switching.html\"  target=\"_top\">PHP Version Switching</a></li>');
document.write('<li class=\"p850\"><a href=\"php_short_open_tags.html\"  target=\"_top\">Short open tags</a></li>');
document.write('<li class=\"p860\"><a href=\"php_cli.html\"  target=\"_top\">PHP CLI</a></li>');


document.write('</ul>');
document.write('</div>');
