document.write('<span class=\"sub_menu_header\">Menu - General</span>');

document.write('<div id=\"lcon1\">');
document.write('<ul class=\"lmen1\">');

document.write('<li class=\"p410\"><a href=\"general_msmtp_intro.html\"      target=\"_top\">MSMTP - Introduction</a></li>');
document.write('<li class=\"p420\"><a href=\"general_msmtp_detail.html\"     target=\"_top\">MSMTP - Detail</a></li>');



document.write('</ul>');
document.write('</div>');
